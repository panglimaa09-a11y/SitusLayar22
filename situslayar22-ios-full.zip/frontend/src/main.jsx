import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home'
import Movie from './pages/Movie'
import Login from './pages/Login'
import Watchlist from './pages/Watchlist'
import './styles.css'
function App(){
  const user = JSON.parse(localStorage.getItem('user')||'null');
  const logout = ()=>{ localStorage.removeItem('token'); localStorage.removeItem('user'); window.location.reload(); }
  return (
    <BrowserRouter>
      <header className="site-header">
        <Link to="/" className="brand">SitusLayar22</Link>
        <nav style={{float:'right'}}>
          <Link to="/watchlist" style={{marginRight:12}}>Watchlist</Link>
          {user ? (
            <>
              {user.role === 'admin' && <Link to="/admin" style={{marginRight:12}}>Admin</Link>}
              <span style={{marginRight:12}}>Hi, {user.name||user.email}</span>
              <button onClick={logout}>Logout</button>
            </>
          ) : (
            <>
              <Link to="/login" style={{marginRight:12}}>Login</Link>
            </>
          )}
        </nav>
      </header>
      <main className="container">
        <div style={{margin:'16px 0', textAlign:'center'}}>
          <ins className="adsbygoogle"
               style={{display:'block', width:'320px', height:'50px', margin:'0 auto', background:'#222'}}
               data-ad-client="ca-pub-XXXXXXXXXXXXXXXX"
               data-ad-slot="1234567890"></ins>
        </div>
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/movie/:id" element={<Movie/>} />
          <Route path="/login" element={<Login/>} />
          <Route path="/watchlist" element={<Watchlist/>} />
        </Routes>
      </main>
    </BrowserRouter>
  )
}
createRoot(document.getElementById('root')).render(<App />);