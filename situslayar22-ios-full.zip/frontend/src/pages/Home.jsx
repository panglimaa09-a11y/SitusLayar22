import React, {useEffect, useState} from 'react';
import MovieCard from '../shared/MovieCard';
export default function Home(){
  const [results, setResults] = useState([]);
  useEffect(()=>{ fetch('http://localhost:4000/api/search?q=').then(r=>r.json()).then(j=>setResults(j.results||[])).catch(()=>setResults([])); },[]);
  return (
    <div>
      <h2>Populer</h2>
      <div className="grid">
        {results.map(m => <MovieCard key={m.id} movie={m} />)}
      </div>
    </div>
  );
}