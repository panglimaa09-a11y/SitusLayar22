import React, {useEffect, useState} from 'react';
import { useParams } from 'react-router-dom';
const IMG_BASE = 'https://image.tmdb.org/t/p/w780';
export default function Movie(){
  const {id} = useParams(); const [m,setM]=useState(null);
  useEffect(()=>{ fetch(`http://localhost:4000/api/movie/${id}`).then(r=>r.json()).then(setM); },[id]);
  if(!m) return <div>Loading...</div>;
  const trailer = m.videos?.results?.find(v=>v.type==='Trailer'&&v.site==='YouTube');
  return (
    <div>
      <h1>{m.title} ({m.release_date?.slice(0,4)})</h1>
      <div className="movie-detail">
        <img src={m.poster_path ? IMG_BASE + m.poster_path : '/favicon.png'} alt={m.title} className="poster"/>
        <div>
          <p>{m.overview}</p>
          {trailer && <iframe title="trailer" width="100%" height="200" src={`https://www.youtube.com/embed/${trailer.key}`} frameBorder="0" allowFullScreen />}
        </div>
      </div>
    </div>
  );
}